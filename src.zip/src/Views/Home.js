import { useEffect, useState } from "react";
import api from "../Components/api";
import { DataGrid } from '@mui/x-data-grid';
import { Button, Label } from "reactstrap";
import FormDialog from "../Components/dialog/Form";
import FormEditDialog from "../Components/dialog/UpdateForm";

export const Home = () => {
    const [customers, setCustomers] = useState([])
    const [selectionIds, setSelectionIds] = useState([]);
    
    const [open, setOpen] = useState(false);
    const [openEdit, setOpenEdit] = useState(false);
    const [itemSelected,  SetItemSelected] = useState();
    
    const columns = [
        { field: 'id', headerName: <b>ID</b>, width: 70 },
        { field: 'name', headerName: <b>Nome</b>, width: 150 },
        { field: 'code', headerName: <b>Código</b>, width: 150 },
        { field: 'cgcCpf', headerName: <b>CGC/CPF</b>, width: 150 },
        { field: 'address', headerName: <b>Endereço</b>, width: 150 },
        { field: 'neighborhood', headerName: <b>Bairro</b>, width: 150 },
        { field: 'city', headerName: <b>Cidade</b>, width: 150 },
        { field: 'phone', headerName: <b>Telefone</b>, width: 150 },
    ];

    const fetchCustomers = async () => {
        const { data } = await api.get('/api/customers');
        setCustomers(data);
        console.log(data);
    }

    function onSelectionModelChange(prop) {
        setSelectionIds(prop);
        console.log(prop);
    }

    function deleteRow() {
        if (selectionIds.length > 0) {
            selectionIds.forEach(async (id) => {
                await api.delete(`/api/customers/${id}`).then(() => {
                    fetchCustomers();
                });
            });
        }
    }

    const handleClickOpen = () => {
        setOpen(true);

    };

    const handleClickOpenEdit = () => {

        const IdItemSelect = selectionIds.length === 1 ? selectionIds.shift() : false;

        if(!IdItemSelect){
            const info = selectionIds.length === 0 ? "Selecione um item na grade" : "Selecione apenas um item para edição"
            alert(info);
            return;
        }   

        SetItemSelected(customers.find(x => x.id === IdItemSelect));
        setOpenEdit(true);

    };


    useEffect(() => {
        fetchCustomers();
    }, []);

    return (
        <>
            <div style={{ height: 600, width: '80%', margin: "auto" }}>
                <DataGrid
                    rows={customers}
                    columns={columns}
                    pageSize={5}
                    rowsPerPageOptions={[5]}
                    checkboxSelection={true}
                    hideFooterSelectedRowCount={true}
                    onSelectionModelChange={onSelectionModelChange} />
            </div>
            <div className="d-flex justify-content-center" >
                <Button style={{ width: 100, height: 50, marginBottom: 10, marginRight: 20 }} onClick={handleClickOpen}> Adicionar </Button>
                <Button style={{ width: 100, height: 50, marginRight: 20 }} onClick={handleClickOpenEdit}> Atualizar </Button>
                <Button style={{ width: 100, height: 50 }} onClick={deleteRow}> Deletar </Button>
            </div>
            
            <FormEditDialog openEdit={openEdit} setOpenEdit={setOpenEdit} itemSelect={itemSelected} />

            <FormDialog open={open} setOpen={setOpen} />



        </>
    );
}
