import React from 'react';


class Headers extends React.Component{

render() {
    return (
        <div className="d-flex justify-content-center">
        <h3> Lista de clientes </h3>
    
        </div>
    );
}

}

export default Headers;