import { useEffect, useState } from "react";
import api from "../api";


import { Button, TextField, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';

export default function FormEditDialog(props) {


  const customersSelect = props.itemSelect;

  const handleCloseEdit = () => {
    props.setOpenEdit(false);
  };
  // const [customers, setCustomers] = useState([]);
  const [editValues, setEditValues] = useState({
    id: 11,
    name: "teste",
    code:  "teste",
    cgcCpf: "teste",
    address:   "teste",
    neighborhood:  "teste",
    city:  "teste",
    phone: "teste",
  });  

  const handleChangeValues = (value) => {
        setEditValues(prevValue => ({
      ...prevValue,
      [value.target.id]: value.target.value,
    }));
  }; 

  const updateRow = async (id) => {
    const { data } = await api.put(`/api/customers/${id}`, {
      id: editValues.id,
      name: editValues.name,
      code: editValues.code,
      cgcCpf: editValues.cgcCpf,
      address: editValues.address,
      neighborhood: editValues.neighborhood,
      city: editValues.city,
      phone: editValues.phone,
    });

    handleCloseEdit();
    console.log(data);

    // fetchCustomers();
  }

  const handleEditClickButton = () => {
    updateRow(props.itemSelect.id);
    console.log(editValues);

  };




  useEffect(() => {
    // fetchCustomers();
    
  }, []);


  return (
    <div>



      <Dialog open={props.openEdit} onClose={handleCloseEdit}>
        <DialogTitle className="d-flex justify-content-center">Editar Cliente</DialogTitle>
        <DialogContent>

          <TextField
            autoFocus
            margin="dense"
            id="id_name"
            name="name"
            label="Nome:"
            type="text"
            onChange={handleChangeValues}
            defaultValue={props?.itemSelect?.id}
            fullWidth
            variant="standard"
          />

          <TextField
            autoFocus
            margin="dense"
            id="id_code"
            name="code"
            label="Código:"
            type="text"
            onChange={handleChangeValues}
            defaultValue={props?.itemSelect?.name}
            fullWidth
            variant="standard"
          />

          <TextField
            autoFocus
            margin="dense"
            id="id_cgcCpf"
            name="cgcCpf"
            label="CGC/CPF:"
            type="text"
            onChange={handleChangeValues}
            defaultValue={props?.itemSelect?.cgcCpf}
            fullWidth
            variant="standard"

          />

          <TextField
            autoFocus
            margin="dense"
            id="id_address"
            name="address"
            label="Endereço:"
            type="text"
            onChange={handleChangeValues}
            defaultValue={props?.itemSelect?.address}
            fullWidth
            variant="standard"
          />

          <TextField
            autoFocus
            margin="dense"
            id="id_neighborhood"
            name="neighborhood"
            label="Bairro:"
            type="text"
            onChange={handleChangeValues}
            defaultValue={props?.itemSelect?.neighborhood}
            fullWidth
            variant="standard"

          />

          <TextField
            autoFocus
            margin="dense"
            id="id_city"
            name="city"
            label="Cidade:"
            type="text"
            onChange={handleChangeValues}
            defaultValue={props?.itemSelect?.city}
            fullWidth
            variant="standard"
          />


          <TextField
            autoFocus
            margin="dense"
            id="id_phone"
            name="phone"
            label="Telefone:"
            type="text"
            onChange={handleChangeValues}
            defaultValue={props?.itemSelect?.phone}
            fullWidth
            variant="standard"

          />

        </DialogContent>
        <DialogActions className="d-flex justify-content-center">

          <Button onClick={handleCloseEdit} >Cancelar</Button>
          <Button onClick={handleEditClickButton} >Editar</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
